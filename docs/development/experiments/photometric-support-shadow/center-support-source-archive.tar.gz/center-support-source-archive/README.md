# Source-only archive: center-connected support shadow diagnostic

This preserves a negative experimental result, not a production gate or scanner
quality claim. Original POLICY.md, run.py, kernel.cpp, results.json and REPORT.md
are byte-for-byte copies. No executable, shared library, image, or log is included.
The original policy and thresholds must remain unchanged when replaying.

## Recorded environment

- Python 3.12.14 (Clang 22.1.3 build)
- NumPy 2.2.6
- g++ (Debian 14.2.0-19) 14.2.0
- Repository: https://github.com/cheshmakzanoon-ops/3d-scanner.git
- Matching header available at commit fba977348d1d4a364a6c9183cf38de6a7ab934f5
- `reconstruction/include/realityforge/matching_cost.hpp` SHA256:
  `8f9de96221746ea58c164d479e8d6154f8f045b422b62d8043c50ea4a0272b03`

## Reproduction in scratch space

Use a scratch directory with these **sibling directory names**, because run.py
expects its parent to contain `3d-scanner`:

```
scratch/
  3d-scanner/                  # repository checkout
  center-support-diagnostic/   # copy of this archive's directory
```

From scratch, after copying the archived diagnostic directory:

```sh
git clone https://github.com/cheshmakzanoon-ops/3d-scanner.git 3d-scanner
git -C 3d-scanner checkout --detach fba977348d1d4a364a6c9183cf38de6a7ab934f5
python3 -m venv .venv
. .venv/bin/activate
python -m pip install numpy==2.2.6
g++ -std=c++20 -O2 -Wall -Wextra -Werror -shared -fPIC \
  -I3d-scanner/reconstruction/include center-support-diagnostic/kernel.cpp \
  -o center-support-diagnostic/kernel.so
cp center-support-diagnostic/results.json center-support-diagnostic/results.recorded.json
python center-support-diagnostic/run.py
```

No Blender or Android SDK is required. A full checkout is convenient, but only
the exact matching header above is required by the C++ wrapper and script.
The original REPORT.md mentions the original local host-validation activation
script; the self-contained venv instructions here replace that local dependency.

## Verification and portability

Run `sha256sum -c SHA256SUMS` from this archive's root before replay. The manifest
covers only included files (excluding itself). Replay writes results.json, so
work on a scratch copy and preserve recorded results first. Source/header hashes,
input-image hashes, per-case counts and full result metadata support comparison.

The original experiment replayed twice with byte-identical results.json SHA256
`1f3da33494b9820b73a326365241340c05e0cb18caaa61179c81e8cb7a7057c2`.
This archive was verified byte-for-byte against those originals. The recorded
`kernel_sha256` is the hash of the original compiled shared object, which is
intentionally excluded. Compiler/linker/toolchain differences may change a rebuilt
binary hash and consequently results.json's hash without changing measurements.
Floating-point/libm differences may also affect numerical outputs. Therefore a
cross-toolchain byte-identical rebuild is NOT claimed. Compare measurements and
image/source hashes explicitly; never erase differences to imply exact reproduction.

A packaged-layout replay is not required to trust the copy verification; no new
measurements or changed policy are represented by this archival operation.
