# Predeclared shadow diagnostic, revision 1

New deterministic analytic two-layer fixtures, not recovery of prior experiments.
No production code edits or acceptance changes. Ground truth is used only for
rendering and post-hoc classification. Images use 128x96 pinhole cameras, f=100,
principal point (63.5,47.5), reference x=0 and source x=0.15 world units. Candidate
camera-z values are the fixed diagnostic grid [2.5,3,3.5,4,4.5,5,5.5,6]. This is
not a complete depth solver or uniqueness/reciprocal validation.

Evaluate 5x5 gray ZNCC using production matching::zncc (variance >=18), byte RGB
and production gray coefficients (77R+150G+29B)/256 with bilinear source sampling.
Baseline positive means NCC>=0.72. All pixels must have valid sampling support.

Reference-only support mask is fixed before any candidate is evaluated: start at
the patch center; flood fill 4-connected neighbors only when their maximum RGB
channel difference is <=24. Require >=9 samples, width and height each >=3 pixels,
and smallest coordinate covariance eigenvalue >=0.35 px^2. Insufficient spatial
support or production variance produces UNKNOWN. For sufficient support, use the
same production ZNCC variance and 0.72 threshold; disagreement with an otherwise
positive full patch is labeled SHADOW_VETO, not applied to geometry.

Predeclared controls: thin foreground strip, rolled strip, same-color layers,
high-contrast texture on one plane, affine exposure, white-balance shift, actual
occlusion, repeated texture, and insufficient support/low texture. Three fixed
radiance seeds (1,7,19), orientations 0 and 35 degrees for strip cases, and a fixed
reference pixel lattice x=61..66,y=45..50. No thresholds will be fitted after
seeing results. Correct hypotheses are within 5.5% relative center depth; others
are wrong. Source visibility is classified post-hoc, never used by the mask.

Question: can this image-derived diagnostic reject baseline-positive wrong
hypotheses without vetoing baseline-positive correct ones? Explicitly report
UNKNOWNs, false vetoes, surviving wrong hypotheses and per-control counts. Even
favorable results would not qualify this as a production gate.
