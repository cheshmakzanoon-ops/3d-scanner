#include "realityforge/matching_cost.hpp"
extern "C" double production_ncc(const double* a,const double* b,unsigned n){
 if(!a||!b||n<1||n>49)return -2;
 const auto c=rf::matching::zncc(std::span<const double>(a,n),std::span<const double>(b,n));
 return c.valid?1.-c.value:-2.;
}
