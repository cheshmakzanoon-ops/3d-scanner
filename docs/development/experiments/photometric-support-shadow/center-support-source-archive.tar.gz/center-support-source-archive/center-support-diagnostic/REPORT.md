# Center-connected support: newly labeled synthetic shadow diagnostic

**Decision: do not promote this diagnostic to a production gate.**
No production code or accepted geometry was changed. This is not a recovery of
lost thin-feature experiments, a scanner quality improvement, or a physical test.

## Measured result

The unchanged full-window NCC threshold of 0.72 produced 1,021 positives among
7,776 fixed candidate-patch evaluations. The proposed shadow veto labeled 106 of
693 wrong positives as disagreement. The remaining 587 wrong positives were
UNKNOWN. All 328 correct positives were UNKNOWN; none were positively supported
and none were vetoed. Consequently, the absence of false vetoes is not evidence
that the support rule can reliably retain correct matches. Treating UNKNOWN as
rejection would remove every correct positive in this fixture set. Treating it
as unaltered leaves most wrong hypotheses unresolved.

| Control | Full positives | Correct UNKNOWN | Wrong SHADOW_VETO | Wrong UNKNOWN |
|---|---:|---:|---:|---:|
| thin foreground/background | 57 | 12 | 28 | 17 |
| rolled strip | 100 | 23 | 33 | 44 |
| same-color layers | 68 | 21 | 0 | 47 |
| high-contrast single plane | 387 | 108 | 0 | 279 |
| affine exposure | 56 | 12 | 27 | 17 |
| white-balance shift | 39 | 10 | 18 | 11 |
| true occlusion | 176 | 58 | 0 | 118 |
| repeated texture | 138 | 84 | 0 | 54 |
| low texture | 0 | 0 | 0 | 0 |

Each control has 864 evaluations. No baseline positive has outcome AGREES.
Correctness is center-depth agreement, not source visibility: 7 correct-depth
positives have occluded source centers; 321 are visible. Among wrong positives,
665 have visible true centers and 28 occluded true centers. Even visible true
centers do not imply every pixel in the full patch corresponds to one surface.

## Frozen policy and tested boundary

POLICY.md was written and hashed before measuring. The reference RGB patch alone
selects a four-connected center component with adjacent max-channel difference
at most 24. Support must have at least 9 samples, span at least 3 pixels on both
axes, and coordinate covariance minimum eigenvalue at least 0.35 px². Failure,
or production NCC variance failure, is explicitly UNKNOWN. The unchanged native
ZNCC helper evaluates full and subset windows. No per-case threshold fitting or
ground-truth mask selection occurred.

New analytic 128x96 pinhole images use f=100, principal point (63.5,47.5), camera
baseline 0.15, and parallel planes at z=3 and z=5. Candidate z is the predeclared
[2.5,3,3.5,4,4.5,5,5.5,6] grid. The lattice is x=61..66,y=45..50, with seeds 1,7,19.
The rolled control alone uses 35 degrees; the other controls use zero degrees.
Thus the policy's shorthand “orientations 0 and 35 degrees for strip cases” was
implemented across controls, not as both orientations for every control.
Repeated-texture and low-texture radiance ignore seed, so their three seed runs
are duplicates, not independent trials. Counts are deterministic evaluations,
not statistical confidence or an independent sample size.

The single-plane high-contrast control is deliberately included: image edges
are not depth edges. This policy did not yield supported correct positives even
there. Same-color layers and occlusion/repetition are unresolved. Color-driven
components may fragment texture, merge depth layers, or lack sufficient variance
and spatial extent; this run does not identify a universal image-only solution.

This is a standalone analytic patch diagnostic, not execution of the published
whole-object Blender benchmark. It reuses the production matching helper and
its gray/bilinear conventions, but does not exercise dense search, uniqueness,
reciprocal tests, registered poses, meshing, Android, or physical scans. None of
these full-window positives should be called production-accepted 3D points.

## Reproduction

From the shared repository directory:

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Werror -shared -fPIC \
  -Ireconstruction/include ../center-support-diagnostic/kernel.cpp \
  -o ../center-support-diagnostic/kernel.so
source ../host-validation/activate.sh
python ../center-support-diagnostic/run.py
```

The script asserts the frozen policy hash and self-checks affine NCC invariance,
flat invalidity, full-component support, thin 1-D rejection, and negative NCC.
Two complete runs produced byte-identical results.json. Source/header/binary and
per-render image hashes are embedded in results.json. SHA256SUMS records all
relevant artifacts; no additional packages or production changes were needed.
