"""New synthetic diagnostic, never a production or whole-object quality test."""
import ctypes, hashlib, json, math
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'3d-scanner'
lib=ctypes.CDLL(str(HERE/'kernel.so'))
lib.production_ncc.argtypes=[ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double),ctypes.c_uint]
lib.production_ncc.restype=ctypes.c_double
POLICY_SHA='85e900a8680ac9029fb972de3d1dc972da2545793c2538ebd38fca3a28cd65a3'
assert hashlib.sha256((HERE/'POLICY.md').read_bytes()).hexdigest()==POLICY_SHA
F=100.; CX=63.5; CY=47.5
DEPTHS=[2.5,3.,3.5,4.,4.5,5.,5.5,6.]
CASES=['thin','rolled','same_color','high_contrast_plane','exposure','white_balance','occlusion','repeated','low_texture']
COORD=np.array([(x,y) for y in range(-2,3) for x in range(-2,3)],dtype=float)

def ncc(a,b):
 a=np.ascontiguousarray(a,dtype=np.float64);b=np.ascontiguousarray(b,dtype=np.float64)
 return lib.production_ncc(a.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),b.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),len(a))

def geometry(u,v,cam,case,angle):
 # Analytic ray/plane rendering. Depth labels never enter support selection.
 xf=(u-CX)*3/F+cam; yf=(v-CY)*3/F
 q=xf*np.cos(angle)+yf*np.sin(angle)
 if case=='high_contrast_plane':fg=np.zeros(np.broadcast_shapes(np.shape(u),np.shape(v)),dtype=bool)
 elif case=='occlusion':fg=np.abs(q-.12)<.055
 else:fg=np.abs(q)<.047
 z=np.where(fg,3.,5.)
 return (u-CX)*z/F+cam,(v-CY)*z/F,z,fg

def render(cam,case,seed,angle):
 v,u=np.indices((96,128),dtype=float);x,y,z,fg=geometry(u,v,cam,case,angle)
 phase=seed*.371
 background=np.stack([140+60*np.sin(x*28+phase)+30*np.cos(y*37),
                      90+55*np.cos(x*33-y*18+phase),
                      150+45*np.sin(y*31+x*13+phase)],axis=-1)
 foreground=np.stack([90+12*np.sin(x*42+y*18+phase),
                      140+14*np.cos(y*44+x*9+phase),
                      70+12*np.sin(x*30-y*28+phase)],axis=-1)
 if case=='same_color':
  # Separate layers share palette and the same world-anchored radiance law.
  foreground=background.copy()
 if case=='repeated':
  t=127+60*np.sin(x*60)+35*np.cos(y*42)
  foreground=background=np.repeat(t[:,:,None],3,axis=2)
 if case=='low_texture':foreground[:]=background[:]=128
 rgb=np.where(fg[:,:,None],foreground,background)
 if cam and case=='exposure':rgb=rgb*.75+25
 if cam and case=='white_balance':rgb=rgb*np.array([.7,1.15,.85])+np.array([20,-5,15])
 return np.rint(np.clip(rgb,0,255)).astype(np.uint8),z

def gray(rgb):return (rgb[...,0].astype(float)*77+rgb[...,1].astype(float)*150+rgb[...,2].astype(float)*29)/256

def support(rgb):
 # Reference image ONLY. Frozen before any candidate warp.
 selected={12}; todo=[12]
 while todo:
  i=todo.pop(); x=i%5;y=i//5
  for xx,yy in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
   if not(0<=xx<5 and 0<=yy<5):continue
   j=yy*5+xx
   if j not in selected and np.max(np.abs(rgb[i].astype(float)-rgb[j].astype(float)))<=24:
    selected.add(j);todo.append(j)
 idx=np.array(sorted(selected),dtype=int);xy=COORD[idx]
 if len(idx)<9:return idx,'sample_count'
 if np.ptp(xy[:,0])<2 or np.ptp(xy[:,1])<2:return idx,'extent'
 covariance=np.cov(xy.T,bias=True)
 if np.linalg.eigvalsh(covariance)[0]<.35:return idx,'spatial_rank'
 return idx,None

def sample(image,u,v):
 # All four source neighbors admitted, matching production bounds behavior.
 if np.any(u<0) or np.any(v<0) or np.any(u>=127) or np.any(v>=95):return None
 x=u.astype(int);y=v.astype(int);fx=u-x;fy=v-y
 return image[y,x]*(1-fx)*(1-fy)+image[y,x+1]*fx*(1-fy)+image[y+1,x]*(1-fx)*fy+image[y+1,x+1]*fx*fy

def test_kernel():
 a=np.array([10.,30.,55.,90.,110.,150.,190.,210.,245.]);b=.7*a+10
 assert abs(ncc(a,b)-1)<1e-12
 assert ncc(np.full(9,128.),np.full(9,128.))==-2
 rgb=np.full((25,3),100,dtype=np.uint8);idx,reason=support(rgb);assert len(idx)==25 and reason is None
 rgb[:]=0;rgb[2::5]=100;idx,reason=support(rgb);assert reason in ('sample_count','extent')
 assert ncc(a,a[::-1])<0

def main():
 test_kernel();rows=[];case_inputs={}
 for case in CASES:
  # Rolled edge is a distinct predeclared control, no result-dependent angles.
  angles=[math.radians(35)] if case=='rolled' else [0.]
  for seed in [1,7,19]:
   for angle in angles:
    ref,truth=render(0.,case,seed,angle);src,_=render(.15,case,seed,angle)
    key=f'{case}:{seed}:{angle:.9f}'
    case_inputs[key]=hashlib.sha256(ref.tobytes()+src.tobytes()).hexdigest()
    sg=gray(src)
    for y in range(45,51):
     for x in range(61,67):
      patch=ref[y-2:y+3,x-2:x+3].reshape(25,3);r=gray(patch);idx,why=support(patch)
      truez=float(truth[y,x]);trueu=x-F*.15/truez
      _,_,source_z,_=geometry(trueu,y,.15,case,angle)
      visible=abs(float(source_z)-truez)<1e-9
      for depth in DEPTHS:
       u=x+COORD[:,0]-F*.15/depth;v=y+COORD[:,1]
       s=sample(sg,u,v)
       full=ncc(r,s) if s is not None else -2.
       center=ncc(r[idx],s[idx]) if why is None and s is not None else -2.
       reason=why or ('variance' if center==-2 else None)
       outcome='UNKNOWN' if reason else ('SHADOW_VETO' if center<.72 else 'AGREES')
       rows.append({'case':case,'seed':seed,'x':x,'y':y,'candidate_depth':depth,
         'true_center_depth':truez,'true_center_visible':visible,
         'correct':abs(depth-truez)/truez<=.055,'full_ncc':full,'baseline_positive':full>=.72,
         'center_ncc':center,'support_count':len(idx),'outcome':outcome,'unknown_reason':reason})
 def summary(group):
  positive=[r for r in group if r['baseline_positive']]
  out={'evaluated':len(group),'baseline_positive':len(positive)}
  for label,good in [('correct',True),('wrong',False)]:
   subset=[r for r in positive if r['correct']==good]
   out[label]={k:sum(r['outcome']==k for r in subset) for k in ['AGREES','SHADOW_VETO','UNKNOWN']}
   out[label]['total']=len(subset)
   out[label]['visible_total']=sum(r['true_center_visible'] for r in subset)
  return out
 report={'schema':1,'status':'SHADOW_ONLY_NOT_A_PRODUCTION_GATE','new_synthetic_fixtures':True,
  'policy_sha256':POLICY_SHA,'camera':{'width':128,'height':96,'f':F,'cx':CX,'cy':CY,'source_x':.15},
  'candidate_depths':DEPTHS,'source_header_sha256':hashlib.sha256((REPO/'reconstruction/include/realityforge/matching_cost.hpp').read_bytes()).hexdigest(),
  'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'kernel_sha256':hashlib.sha256((HERE/'kernel.so').read_bytes()).hexdigest(),
  'input_image_hashes':case_inputs,'total':summary(rows),'cases':{c:summary([r for r in rows if r['case']==c]) for c in CASES},
  'examples':{'false_vetoes':[r for r in rows if r['baseline_positive'] and r['correct'] and r['outcome']=='SHADOW_VETO'][:12],
              'wrong_survivors':[r for r in rows if r['baseline_positive'] and not r['correct'] and r['outcome']=='AGREES'][:12]},
  'limitations':['Fixed depth hypotheses, not dense search/uniqueness/reciprocal verification.','Small synthetic analytic views; no physical data, recovered poses, mesh or Android execution.','Unknowns are not silently called rejections or passes.','Ground truth did not select support, alter thresholds or candidates per pixel.']}
 (HERE/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'total':report['total'],'cases':report['cases']},indent=2))
if __name__=='__main__':main()
