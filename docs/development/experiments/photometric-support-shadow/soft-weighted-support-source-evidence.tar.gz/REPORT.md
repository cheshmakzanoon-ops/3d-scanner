# Frozen bilateral support trial: FAIL, shadow only

No repository edits or accepted geometry. All accepted labels below are **photometric-only hypothesis decisions**. Reciprocal verification **NOT_RUN**: source depth maps were not independently solved; rendered depth is used only to score correctness and report true-center visibility, never to verify candidates.

## Decision and numbers

Across324pixel decisions (9families×2freshseeds×2rollsettings×9pixels), uniformly weighted proposal search accepted1wrong/0correct. Fixed bilateral weighting accepted17wrong/5correct. UNKNOWN increased36→40; REJECT decreased287→262. Strict predeclared success **failed overall and in every family**. There is no support for promoting this weighting to production.

| Family | Uniform correct/wrong | Weighted correct/wrong | Weighted UNKNOWN |
|---|---:|---:|---:|
| Genuine slanted plane |0/0|4/0|0|
| Thin two-layer |0/0|0/0|0|
| Same-color layers |0/1|0/0|0|
| High-contrast single plane |0/0|0/10|4|
| Exposure |0/0|0/0|0|
| White balance |0/0|0/2|0|
| Occlusion |0/0|0/0|0|
| Repeated texture |0/0|1/5|0|
| Flat |0/0|0/0|36|

There are no lost uniform-correct positives only because the uniform comparator accepted **zero** correct positives. Thus that condition is vacuous, not proof of recall preservation. The5weighted-correct positives show some center-depth observability in this tiny fixture, not independently supported geometry. Of22weighted acceptances,17 selected sources see the true center and5 do not; visibility is posthoc and did not alter acceptance. Same-color wrong suppression is not a success because it retains no correct positives. High-contrast and repeated textures introduce substantial new wrong acceptances.

The weighted effective support ranges4.4853–12.1144 of25samples. Weighted spatial covariance smallest eigenvalue minimum0.29123pixel², largest eigenvalue maximum1.10474pixel². Accepted weighted reference variance33.235–1024.199 and source variance32.944–895.854 in intensity². Selected weighted source counts8(left)/14(right). Uniform source counts1(left)/0(right). Each row contains selected plane/source, per-source selected-hypothesis costs, valid candidate counts, true-center visibility, variances, effective support, and spatial eigenvalues. No additional support/conditioning gate was fitted after seeing these results.

## Method and reproducibility

Frozen policy SHA256: `9b307f78b62dc5cf6abbafbe6324e09843f0524cfee7c6c93dbd4963e393f506`.

Original implementation in `run.py`, with tiny C++ shim invoking the unmodified repository NCC for parity tests. Reference grayscale weights use sigma_color=.2(normalized0..1), sigma_spatial=1pixel; NCC variance remains18 in0..255 intensity domain. Fixed96inverse-depth candidates,5inverse-plane slope proposals,2sources, same complete candidate array and invalid sampling in both arms. MIN over sources then normals produces the depth envelope; observed runner outside3indices is required, minimum NCC.72, uniqueness.025, depth-edge2 exclusion. We never tune thresholds or proposals based on truth. Proposals are independent of scene slopes.

This is **uniform proposal-search comparator**, not current production default: early normal search can explore hypotheses that the current production gate order cannot reach. Plane score minimum and source MIN can themselves admit ambiguity and are not independent corroboration.

Numerical tests passed:100random uniform-weight cases match the production NCC to1e-12;100fixed-weight positive-affine cases invariant to1e-12; nonfinite/negative/zero weights reject; nonfinite/out-of-range intensity and flat variance reject; no usable observed alternative producesUNKNOWN; an observed alternative restores acceptance. All valid random costs remain0..2. Fixed-weight affine invariance does not claim bilateral weights are invariant when reference exposure itself changes.

Canonical results and all complete candidate costs reproduced byte-for-byte on a second execution. `curves.npy` shape648×96×5×2, float64; alternating uniform/weighted rows follow `results.json` row order, final axis source[-.15,.15]. Full array includes invalid candidates represented bycost2, consistent with the current observed-alternative boundary. Image hashes and implementation/header hashes are in results. No runtime timestamps enter canonical output.

Run from repository root:
```
source ../host-validation/activate.sh
g++ -std=c++20 -shared -fPIC -I reconstruction/include ../soft-weighted-support-diagnostic/kernel.cpp -o ../soft-weighted-support-diagnostic/kernel.so
python ../soft-weighted-support-diagnostic/run.py
```

## Important limits and preserved negative evidence

These are fresh deterministic analytic synthetic fixtures (seeds43/71,striproll17/53), not a held-out physical validation set. Single-plane families have no strip boundary, so the roll argument does not change their images; their two roll settings are duplicates. Flat images repeat across seeds/rolls. There are29unique image triplets among36case settings. The4slanted correct decisions include repeated roll controls, not4independent image experiments. Reported totals retain the frozen schedule rather than silently dropping repeats. Policy's stray text `Bounded576? exact` is a prose typo; the explicit formula324 and executable schedule agree. No post-result fixture/parameter changes were made.

Uniform baseline's zero correct accepted pixels limits comparative recall conclusions.286of287uniform rejections fail uniqueness (74alsofailNCC);255of262weighted rejections fail uniqueness (79alsofailNCC). These are nonexclusive reasons, not disjoint counts. The fixed smooth textures and dense depth grid can produce shallow curves. We did not relax uniqueness to create positives.

This does not test whole-image independent source-depth solving, reciprocal correspondence, recovered/perturbed camera poses, real captures, full visible-surface coverage, dense engine equivalence, meshing, Android performance, or offline device journey. No claim of fixing thin geometry. The earlier hard connected-support diagnostic's negative result (all328correct positivesUNKNOWN) remains unchanged; softer support is a different failed trial, not a retroactive repair.

Primary math references: COLMAP `gpu_mat_ref_image.h::BilateralWeightComputer` and `patch_match_cuda.cu`; OpenMVS `DepthMap.h::GetWeight`. Formula is implemented originally; no OpenMVS AGPL code copied. Sigma/support choices are this experiment's choices, not a claim of source-default replication. See frozen policy for URLs.

## Posthoc oracle/control audit (not fed into acceptance)

Requested after the frozen result, `oracle_audit.py` evaluates true plane warps only to diagnose fixture/warp observability. It changes no original results, candidates, filters or weights. Single-plane duplicate roll settings are removed for this audit only, leaving18unique referencepixels×2sources per family. The audit is not a held-out confirmation or reciprocal verification.

Analytic reference→source→plane XYZ roundtrip error is below1e-12 for every audited patch. Genuine slanted-plane true-depth/normal warps have uniform NCC.996696–.999462 and weighted NCC.993273–.999618, all36source-pixel pairs valid and above.72. This is a positive well-observed photometric control. All36scheduled uniform slanted-plane best depths are also correct and cost<=.003001, but uniqueness margins.010789–.022557 fall below.025; that is why none is accepted. We did not change uniqueness to remedy this. The zero-correct baseline therefore reflects the fixed acceptance curve rather than a stereo projection bug in this control.

Nearest scheduled center depth error is.0968%–.5593%; best scheduled plane's maximum patch inverse-depth error is.8930%–1.3452%. The actual scene relative inverse slopes lie between the frozen candidate slopes; exact normal is intentionally absent. These quantization diagnostics are posthoc truth-based measurements, not proposals.

High-contrast plane oracle uniform NCC.655523–.932360 (33of36above.72). Weighted oracle has4variance-invalid pairs; remaining32valid NCC.072164–.357543 (noneabove.72). This is consistent with support concentration combined with sharp-edge/raster sampling difficulty. It does not establish which effect dominates without a separately frozen future experiment. Raw audit invalid records have cost2/NCC sentinel-1 with an explicit valid=false; summary ranges exclude these invalid sentinels.

Conclusion is narrowly scoped: this frozen sigma/support/proposal/threshold combination introduces observed false positives and fails its predeclared gate. **It does not show bilateral weighting generally invalid.** Comparative accepted-recall claims remain inconclusive because uniform accepted-correct count is zero. Current production stays unchanged.
