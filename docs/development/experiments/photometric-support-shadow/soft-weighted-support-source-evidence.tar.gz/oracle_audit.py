"""Posthoc calibration diagnostic only. NEVER changes run.py decisions or thresholds."""
import json,hashlib
import numpy as np
import run as d
rows=[]
for case in ['slanted_plane','high_contrast']:
 for seed in [43,71]:
  rgb,truth=d.render(0,case,seed,np.deg2rad(17));ref=d.gray(rgb);sources=[d.gray(d.render(c,case,seed,np.deg2rad(17))[0]) for c in d.CAMS]
  for y in [45,47,49]:
   for x in [61,63,65]:
    a=ref[y-2:y+3,x-2:x+3].reshape(25);w=np.exp(-np.sum(d.XY**2,axis=-1)/2-(a-a[12])**2/(2*(.2*255)**2))
    z0=truth[y,x];true_inv=(1-.23*(x+d.XY[:,0]-63.5)/100+.17*(y+d.XY[:,1]-47.5)/100)/4.2
    k=int(np.argmin(np.abs(d.DEPTH-z0)));slopes=np.array([-.23,.17])*z0/420
    errors=[float(np.max(np.abs((1+np.sum(s*d.XY,axis=-1))/d.DEPTH[k]-true_inv)/true_inv)) for s in d.SLOPES]
    row={'family':case,'seed':seed,'x':x,'y':y,'true_depth':float(z0),'nearest_grid_depth':float(d.DEPTH[k]),'nearest_grid_depth_relative_error':float(abs(d.DEPTH[k]-z0)/z0),'true_relative_inverse_slopes':slopes.tolist(),'minimum_max_patch_inverse_depth_relative_error':min(errors),'source':[]}
    for cam,src in zip(d.CAMS,sources):
     u=x+d.XY[:,0]-100*cam*true_inv;v=y+d.XY[:,1];s=d.sample(src,u,v)
     X,Y,Z,_=d.geom(x+d.XY[:,0],v,0,case,0);Xs,Ys,Zs,_=d.geom(u,v,cam,case,0)
     err=max(float(np.max(np.abs(X-Xs))),float(np.max(np.abs(Y-Ys))),float(np.max(np.abs(Z-Zs))))
     assert err<1e-12
     row['source'].append({'x':cam,'roundtrip_max_xyz_error':err,'uniform_oracle_ncc':float(1-d.cost(a,s,np.ones(25))[0]),'weighted_oracle_ncc':float(1-d.cost(a,s,w)[0]),'uniform_valid':bool(d.cost(a,s,np.ones(25))[1]),'weighted_valid':bool(d.cost(a,s,w)[1])})
    rows.append(row)
summary={}
for case in ['slanted_plane','high_contrast']:
 rr=[r for r in rows if r['family']==case]
 out={'unique_pixels':len(rr),'depth_grid_relative_error_range':[min(r['nearest_grid_depth_relative_error'] for r in rr),max(r['nearest_grid_depth_relative_error'] for r in rr)],'best_available_plane_patch_inverse_error_range':[min(r['minimum_max_patch_inverse_depth_relative_error'] for r in rr),max(r['minimum_max_patch_inverse_depth_relative_error'] for r in rr)]}
 for arm in ['uniform','weighted']:
  v=[r['source'][i][arm+'_oracle_ncc'] for r in rr for i in range(2) if r['source'][i][arm+'_valid']];out[arm+'_oracle_valid_ncc_range']=[min(v),max(v)] if v else None;out[arm+'_oracle_invalid']=36-len(v);out[arm+'_oracle_ncc_at_least_072']=sum(z>=.72 for z in v)
 summary[case]=out
report={'status':'POSTHOC_ORACLE_AUDIT_NOT_ACCEPTANCE','changes_to_frozen_trial':'NONE','roll_duplicates_removed_only_for_audit':True,'main_results_sha256':hashlib.sha256((d.H/'results.json').read_bytes()).hexdigest(),'audit_source_sha256':hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest(),'summary':summary,'rows':rows}
(d.H/'oracle_audit.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,indent=2))
