"""Original frozen synthetic photometric diagnostic; not production geometry."""
import ctypes,hashlib,json,math
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent;R=H.parent/'3d-scanner'
POL='9b307f78b62dc5cf6abbafbe6324e09843f0524cfee7c6c93dbd4963e393f506'
assert hashlib.sha256((H/'POLICY.md').read_bytes()).hexdigest()==POL
XY=np.array([(x,y) for y in range(-2,3) for x in range(-2,3)],float)
DEPTH=1/np.linspace(1/6.5,1/2.4,96)
SLOPES=np.array([[-.006,0],[0,0],[.006,0],[0,-.006],[0,.006]])
CAMS=[-.15,.15]; CASES=['slanted_plane','thin_two_layer','same_color','high_contrast','exposure','white_balance','occlusion','repeated','flat']

def cost(a,b,w):
 a=np.asarray(a,float);b=np.asarray(b,float);w=np.asarray(w,float)
 if a.shape!=b.shape or a.shape[-1]!=len(w) or not len(w) or len(w)>49 or not np.all(np.isfinite(w)) or np.any(w<0) or w.sum()<=0:raise ValueError('invalid weights/shape')
 w=w/w.sum();am=np.sum(a*w,axis=-1);bm=np.sum(b*w,axis=-1)
 av=np.sum((a-am[...,None])**2*w,axis=-1);bv=np.sum((b-bm[...,None])**2*w,axis=-1)
 cov=np.sum((a-am[...,None])*(b-bm[...,None])*w,axis=-1)
 valid=np.all(np.isfinite(a)&np.isfinite(b)&(a>=0)&(a<=255)&(b>=0)&(b<=255),axis=-1)&(av>=18)&(bv>=18)&(av>0)&(bv>0)
 with np.errstate(invalid='ignore',divide='ignore'):c=1-np.clip(cov/np.sqrt(av*bv),-1,1)
 return np.where(valid,c,2.),valid,av,bv

def decide(curve):
 i=int(np.argmin(curve));others=(np.abs(np.arange(96)-i)>3)&(curve<2)
 if curve[i]>=2 or not others.any():return 'UNKNOWN',i,0.
 margin=float(np.min(curve[others])-curve[i])
 return ('ACCEPT' if 2<=i<94 and curve[i]<=.28 and margin>=.025 else 'REJECT'),i,margin

def geom(u,v,cam,case,ang):
 rx=(u-63.5)/100;ry=(v-47.5)/100
 if case in ['slanted_plane','high_contrast']:
  z=(4.2+.23*cam)/(1-.23*rx+.17*ry);fg=np.zeros_like(z,bool)
 else:
  q=(rx*3+cam)*np.cos(ang)+(ry*3)*np.sin(ang)
  fg=np.abs(q-(.12 if case=='occlusion' else 0))<(.055 if case=='occlusion' else .045);z=np.where(fg,3.,5.)
 return rx*z+cam,ry*z,z,fg

def render(cam,case,seed,ang):
 v,u=np.indices((96,128),dtype=float);x,y,z,fg=geom(u,v,cam,case,ang)
 rng=np.random.default_rng(seed);p=rng.uniform(-np.pi,np.pi,6)
 bg=np.stack([130+50*np.sin(x*23+p[0])+25*np.cos(y*31+p[1]),110+50*np.cos(x*29-y*17+p[2]),145+45*np.sin(y*27+x*11+p[3])],axis=-1)
 front=np.stack([65+25*np.sin(x*37+y*19+p[4]),170+25*np.cos(y*39+x*7+p[5]),75+20*np.sin(x*29-y*23+p[0])],axis=-1)
 if case=='same_color':front=bg.copy()
 if case=='repeated':
  t=127+65*np.sin(x*65+p[0])+30*np.cos(y*45+p[1]);front=bg=np.repeat(t[...,None],3,axis=-1)
 if case=='high_contrast':bg=np.where((np.sin(x*24+p[0])*np.cos(y*27+p[1])>0)[...,None],215.,35.)*np.ones_like(bg)
 if case=='flat':front[:]=bg[:]=128
 rgb=np.where(fg[...,None],front,bg)
 if cam and case=='exposure':rgb=.75*rgb+25
 if cam and case=='white_balance':rgb=rgb*np.array([.7,1.15,.85])+np.array([20,-5,15])
 rgb=np.rint(np.clip(rgb,0,255)).astype(np.uint8)
 return rgb,z

def gray(a):return np.sum(a.astype(float)*[77,150,29],axis=-1)/256

def sample(a,u,v):
 ok=(u>=0)&(v>=0)&(u<127)&(v<95)
 xx=np.clip(u,0,126.999);yy=np.clip(v,0,94.999);x=xx.astype(int);y=yy.astype(int);fx=xx-x;fy=yy-y
 out=a[y,x]*(1-fx)*(1-fy)+a[y,x+1]*fx*(1-fy)+a[y+1,x]*(1-fx)*fy+a[y+1,x+1]*fx*fy
 return np.where(ok,out,np.nan)

def tests():
 lib=ctypes.CDLL(str(H/'kernel.so'));fn=lib.production_ncc;fn.argtypes=[ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double),ctypes.c_uint];fn.restype=ctypes.c_double
 rng=np.random.default_rng(901)
 for _ in range(100):
  a=rng.uniform(10,230,25);b=rng.uniform(10,230,25);c,ok,_,_=cost(a,b,np.ones(25))
  expected=fn(a.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),b.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),25)
  assert ok and abs(float(c)-(1-expected))<1e-12 and 0<=c<=2
  w=rng.uniform(.01,1,25);c1=cost(a,b,w)[0];c2=cost(.7*a+10,.8*b+5,w)[0];assert abs(c1-c2)<1e-12
 for w in [np.zeros(25),np.full(25,-1.),np.full(25,np.nan)]:
  try:cost(a,b,w);assert False
  except ValueError:pass
 for bad in [np.full(25,np.nan),np.full(25,-1.),np.full(25,256.)]:assert not cost(a,bad,np.ones(25))[1]
 assert not cost(np.ones(25)*100,np.ones(25)*100,np.ones(25))[1]
 c=np.full(96,2.);c[30]=.1;assert decide(c)[0]=='UNKNOWN';c[40]=.2;assert decide(c)[0]=='ACCEPT'
 return {'random_uniform_parity_cases':100,'weighted_fixed_weight_affine_cases':100,'invalid_zero_negative_nonfinite_weights':'PASS','invalid_intensity_flat_variance':'PASS','observed_alternative':'PASS'}

def main():
 test=tests();rows=[];hashes={};curves=[]
 inv=(1+np.sum(SLOPES[:,None,:]*XY[None,:,:],axis=-1))[None,:,:]/DEPTH[:,None,None]
 for case in CASES:
  for seed in [43,71]:
   for degrees in [17,53]:
    ang=np.deg2rad(degrees);rgb,truth=render(0,case,seed,ang);ref=gray(rgb);sources=[render(c,case,seed,ang)[0] for c in CAMS]
    key=f'{case}:{seed}:{degrees}';hashes[key]=[hashlib.sha256(a.tobytes()).hexdigest() for a in [rgb]+sources]
    for y in [45,47,49]:
     for x in [61,63,65]:
      a=ref[y-2:y+3,x-2:x+3].reshape(25);w=np.exp(-np.sum(XY**2,axis=-1)/2-(a-a[12])**2/(2*(.2*255)**2));wn=w/w.sum();mu=np.sum(XY*wn[:,None],axis=0);cov=(XY-mu).T@((XY-mu)*wn[:,None]);ev=np.linalg.eigvalsh(cov)
      samples=[sample(gray(src),x+XY[:,0]-100*cam*inv,y+np.broadcast_to(XY[:,1],inv.shape)) for cam,src in zip(CAMS,sources)]
      row={'family':case,'seed':seed,'roll':degrees,'x':x,'y':y,'truth_depth':float(truth[y,x]),'effective_support':float(w.sum()**2/np.sum(w*w)),'spatial_eigenvalues':ev.tolist(),'source_true_center_visible':[]}
      for cam in CAMS:
       _,_,sz,_=geom(x-100*cam/truth[y,x],y,cam,case,ang);row['source_true_center_visible'].append(bool(abs(sz-truth[y,x])<1e-8))
      for arm,weights in [('uniform',np.ones(25)),('weighted',w)]:
       full=[cost(np.broadcast_to(a,s.shape),s,weights) for s in samples];allcost=np.stack([q[0] for q in full],axis=-1)
       envelope=np.min(allcost,axis=(1,2));status,i,margin=decide(envelope);p,source=np.unravel_index(np.argmin(allcost[i]),allcost[i].shape)
       row[arm]={'status':status,'depth':float(DEPTH[i]),'correct':bool(abs(DEPTH[i]-truth[y,x])/truth[y,x]<=.055),'cost':float(envelope[i]),'margin':margin,'normal_index':int(p),'source_index':int(source),'source_x':CAMS[source],'reference_variance':float(full[source][2][i,p]),'source_variance':float(full[source][3][i,p]),'per_source_costs':allcost[i,p,:].tolist(),'valid_candidates_per_source':[int(q[1].sum()) for q in full]}
       curves.append(allcost)
      rows.append(row)
 def summarize(rs):
  out={}
  for arm in ['uniform','weighted']:
   out[arm]={s:sum(r[arm]['status']==s for r in rs) for s in ['ACCEPT','REJECT','UNKNOWN']}
   out[arm].update({kind+'_accepted':sum(r[arm]['status']=='ACCEPT' and r[arm]['correct']==good for r in rs) for kind,good in [('correct',True),('wrong',False)]})
  out['lost_uniform_correct']=sum(r['uniform']['status']=='ACCEPT' and r['uniform']['correct'] and not(r['weighted']['status']=='ACCEPT' and r['weighted']['correct']) for r in rs)
  out['success']=bool(out['weighted']['wrong_accepted']<out['uniform']['wrong_accepted'] and out['lost_uniform_correct']==0 and out['weighted']['correct_accepted']>0)
  out['effective_support_range']=[min(r['effective_support'] for r in rs),max(r['effective_support'] for r in rs)]
  return out
 result={'status':'SHADOW_ONLY_PHOTOMETRIC_ONLY','reciprocal':'NOT_RUN','policy_sha256':POL,'tests':test,'source_hashes':{str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in [H/'run.py',H/'kernel.cpp',R/'reconstruction/include/realityforge/matching_cost.hpp']},'image_hashes':hashes,'total':summarize(rows),'families':{c:summarize([r for r in rows if r['family']==c]) for c in CASES},'rows':rows}
 result['predeclared_success']=all(s['success'] for s in result['families'].values())
 arrays=np.stack(curves);np.save(H/'curves.npy',arrays);result['complete_curves_sha256']=hashlib.sha256((H/'curves.npy').read_bytes()).hexdigest();result['complete_curves_shape']=list(arrays.shape)
 (H/'results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:result[k] for k in ['total','families','predeclared_success']},indent=2))
if __name__=='__main__':main()
